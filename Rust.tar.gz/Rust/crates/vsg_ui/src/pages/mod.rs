//! Pages module - main application views.

pub mod main_window;
