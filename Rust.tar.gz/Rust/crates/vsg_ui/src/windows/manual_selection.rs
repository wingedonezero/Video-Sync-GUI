//! Manual selection window view.
//!
//! Dialog for manually selecting and arranging tracks for a job's output.
//! Left pane shows available tracks from sources, right pane shows final output.
//! Final output list supports drag-and-drop reordering.

use iced::widget::{button, checkbox, column, container, row, scrollable, text, Space};
use iced::{Alignment, Background, Border, Color, Element, Length, Theme};

use crate::app::{App, FinalTrackState, Message};
use crate::widgets::reorderable_list;

/// Build the manual selection window view.
pub fn view(app: &App) -> Element<'_, Message> {
    // Header with job info
    let job_name = app.manual_selection_job_idx
        .and_then(|idx| {
            let q = app.job_queue.lock().unwrap();
            q.jobs().get(idx).map(|j| j.name.clone())
        })
        .unwrap_or_else(|| "Unknown Job".to_string());

    let header = row![
        text("Manual Track Selection").size(24),
        Space::new().width(Length::Fill),
        text(job_name).size(14),
    ]
    .align_y(Alignment::Center);

    // Info message
    let info_text: Element<'_, Message> = if app.manual_selection_info.is_empty() {
        text("Click tracks to add them to the final output. Drag to reorder.").size(13).into()
    } else {
        text(&app.manual_selection_info).size(13).into()
    };

    // =========================================================================
    // LEFT PANE: Source groups with tracks
    // =========================================================================
    let source_groups: Vec<Element<'_, Message>> = app
        .source_groups
        .iter()
        .map(|group| {
            // Group header with source name
            let group_header = container(
                text(&group.title).size(14)
            )
            .padding([6, 8])
            .width(Length::Fill)
            .style(|_theme: &Theme| container::Style {
                background: Some(Background::Color(Color::from_rgb(0.18, 0.18, 0.18))),
                ..Default::default()
            });

            // Track rows - 2 lines per track
            let tracks: Vec<Element<'_, Message>> = group
                .tracks
                .iter()
                .map(|track| {
                    let track_id = track.id;
                    let source_key = group.source_key.clone();

                    let icon = match track.track_type.as_str() {
                        "video" => "🎬",
                        "audio" => "🔊",
                        "subtitles" => "💬",
                        _ => "📄",
                    };

                    // Line 1: icon + main summary + badges
                    let line1 = row![
                        text(icon).width(20),
                        text(&track.summary).width(Length::Fill),
                        text(&track.badges).size(10),
                    ]
                    .spacing(4)
                    .align_y(Alignment::Center);

                    // Line 2: codec details
                    let line2 = row![
                        Space::new().width(20),
                        text(&track.codec_id).size(11).color(Color::from_rgb(0.6, 0.6, 0.6)),
                    ]
                    .spacing(4);

                    let track_content = column![line1, line2].spacing(2);

                    let track_btn = button(track_content)
                        .on_press(Message::SourceTrackDoubleClicked {
                            track_id,
                            source_key
                        })
                        .width(Length::Fill)
                        .padding([6, 8])
                        .style(move |_theme, _status| {
                            button::Style {
                                background: Some(Background::Color(Color::TRANSPARENT)),
                                text_color: Color::from_rgb(0.9, 0.9, 0.9),
                                border: Border::default(),
                                ..Default::default()
                            }
                        });

                    if track.is_blocked {
                        container(track_btn)
                            .style(|_theme| container::Style {
                                text_color: Some(Color::from_rgb(0.5, 0.5, 0.5)),
                                ..Default::default()
                            })
                            .into()
                    } else {
                        track_btn.into()
                    }
                })
                .collect();

            column![
                group_header,
                column(tracks).spacing(1),
            ]
            .spacing(0)
            .into()
        })
        .collect();

    // External subtitles section (if any)
    let external_section: Element<'_, Message> = if app.external_subtitles.is_empty() {
        Space::new().height(0).into()
    } else {
        let ext_items: Vec<Element<'_, Message>> = app.external_subtitles
            .iter()
            .enumerate()
            .map(|(idx, path)| {
                let filename = path.file_name()
                    .map(|n| n.to_string_lossy().to_string())
                    .unwrap_or_else(|| path.to_string_lossy().to_string());
                row![
                    text("💬").width(20),
                    text(filename).width(Length::Fill).size(13),
                    button("✕").on_press(Message::FinalTrackRemoved(idx)), // TODO: proper external sub removal
                ]
                .spacing(4)
                .padding([4, 8])
                .into()
            })
            .collect();

        column![
            container(text("External Subtitles").size(14))
                .padding([6, 8])
                .width(Length::Fill)
                .style(|_theme: &Theme| container::Style {
                    background: Some(Background::Color(Color::from_rgb(0.18, 0.18, 0.18))),
                    ..Default::default()
                }),
            column(ext_items).spacing(1),
        ]
        .spacing(0)
        .into()
    };

    let left_pane = column![
        text("Available Tracks").size(16),
        Space::new().height(8),
        container(
            scrollable(
                column![
                    column(source_groups).spacing(8),
                    external_section,
                ]
                .spacing(12)
            )
            .height(Length::Fill)
        )
        .style(container::bordered_box)
        .height(Length::Fill),
        Space::new().height(8),
        button("Add External Subtitle(s)...").on_press(Message::AddExternalSubtitles),
    ]
    .spacing(4)
    .width(Length::FillPortion(1))
    .height(Length::Fill);

    // =========================================================================
    // RIGHT PANE: Final output + attachments (with drag-and-drop reordering)
    // =========================================================================
    let final_list: Element<'_, Message> = {
        let reorderable = reorderable_list::view(
            &app.final_tracks,
            &app.drag_state,
            render_final_track_row,
        );
        scrollable(reorderable)
            .height(Length::Fill)
            .into()
    };

    // Attachments section (pinned at bottom)
    let attachment_checks: Vec<Element<'_, Message>> = app
        .source_groups
        .iter()
        .map(|group| {
            let key = group.source_key.clone();
            let key_for_toggle = key.clone();
            let checked = app.attachment_sources.get(&key).copied().unwrap_or(false);
            checkbox(checked)
                .label(key)
                .on_toggle(move |v| Message::AttachmentToggled(key_for_toggle.clone(), v))
                .into()
        })
        .collect();

    let right_pane = column![
        text("Final Output").size(16),
        Space::new().height(8),
        container(final_list)
            .style(container::bordered_box)
            .height(Length::FillPortion(1)),
        Space::new().height(12),
        text("Include Attachments From:").size(14),
        Space::new().height(4),
        row(attachment_checks).spacing(16),
    ]
    .spacing(4)
    .width(Length::FillPortion(2))  // Right pane is wider
    .height(Length::Fill);

    // =========================================================================
    // MAIN LAYOUT
    // =========================================================================
    let panes = row![
        left_pane,
        Space::new().width(16),
        right_pane,
    ]
    .height(Length::Fill);

    // Dialog buttons
    let dialog_buttons = row![
        Space::new().width(Length::Fill),
        button("Accept Layout").on_press(Message::AcceptLayout),
        button("Cancel").on_press(Message::CloseManualSelection),
    ]
    .spacing(8);

    let content = column![
        header,
        Space::new().height(4),
        info_text,
        Space::new().height(12),
        panes,
        Space::new().height(12),
        dialog_buttons,
    ]
    .spacing(4)
    .padding(16)
    .height(Length::Fill);

    container(content)
        .width(Length::Fill)
        .height(Length::Fill)
        .into()
}

/// Render a single final track row for the reorderable list.
///
/// # Arguments
/// * `track` - The track state to render
/// * `idx` - The index in the list
/// * `is_dragging` - Whether this row is currently being dragged
/// * `is_drop_target` - Whether this row is the current drop target
fn render_final_track_row<'a>(
    track: &'a FinalTrackState,
    idx: usize,
    _is_dragging: bool,
    _is_drop_target: bool,
) -> Element<'a, Message> {
    let icon = match track.track_type.as_str() {
        "video" => "🎬",
        "audio" => "🔊",
        "subtitles" => "💬",
        _ => "📄",
    };

    // Generate badges for this track
    let badges = track.badges();

    // Line 1: index + icon + summary + badges + source tag
    let mut line1_elements: Vec<Element<'_, Message>> = vec![
        text(format!("{}.", idx + 1)).width(24).into(),
        text(icon).width(20).into(),
        text(&track.summary).width(Length::Fill).size(13).into(),
    ];

    // Add badges (if any)
    if !badges.is_empty() {
        line1_elements.push(
            container(text(badges).size(10).color(Color::from_rgb(0.7, 0.85, 1.0)))
                .padding([2, 6])
                .style(|_theme: &Theme| container::Style {
                    background: Some(Background::Color(Color::from_rgb(0.2, 0.3, 0.4))),
                    border: Border {
                        radius: 3.0.into(),
                        ..Default::default()
                    },
                    ..Default::default()
                })
                .into(),
        );
    }

    // Add source tag
    line1_elements.push(
        container(text(&track.source_key).size(10))
            .padding([2, 6])
            .style(|_theme: &Theme| container::Style {
                background: Some(Background::Color(Color::from_rgb(0.25, 0.25, 0.25))),
                border: Border {
                    radius: 3.0.into(),
                    ..Default::default()
                },
                ..Default::default()
            })
            .into(),
    );

    let line1 = row(line1_elements).spacing(4).align_y(Alignment::Center);

    // Line 2: controls (D/F checkboxes, drag handle hint, settings, delete)
    // Note: Up/down buttons removed - use drag-and-drop to reorder
    let line2 = row![
        Space::new().width(44), // align with icon column
        checkbox(track.is_default)
            .label("Default")
            .on_toggle(move |v| Message::FinalTrackDefaultChanged(idx, v)),
        checkbox(track.is_forced_display)
            .label("Forced")
            .on_toggle(move |v| Message::FinalTrackForcedChanged(idx, v)),
        Space::new().width(Length::Fill),
        text("☰").size(16).color(Color::from_rgb(0.5, 0.5, 0.5)), // Drag handle hint
        Space::new().width(8),
        button("⚙").on_press(Message::FinalTrackSettingsClicked(idx)).width(28),
        button("✕").on_press(Message::FinalTrackRemoved(idx)).width(28),
    ]
    .spacing(4)
    .align_y(Alignment::Center);

    column![line1, line2].spacing(4).into()
}
