//! Windows module - secondary window views.

pub mod settings;
pub mod job_queue;
pub mod add_job;
pub mod manual_selection;
pub mod track_settings;
