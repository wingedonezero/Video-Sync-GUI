# This file makes the vsg_core directory a Python package.
