# vsg_qt/ocr_dictionary_dialog/__init__.py
from .ui import OCRDictionaryDialog

__all__ = ['OCRDictionaryDialog']
