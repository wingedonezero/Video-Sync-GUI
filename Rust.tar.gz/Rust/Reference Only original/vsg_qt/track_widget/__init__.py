# Re-export to preserve existing imports:
# from vsg_qt.track_widget import TrackWidget
from .ui import TrackWidget

__all__ = ["TrackWidget"]
