# Re-export to preserve existing imports:
# from vsg_qt.manual_selection_dialog import ManualSelectionDialog
from .ui import ManualSelectionDialog

__all__ = ["ManualSelectionDialog"]
