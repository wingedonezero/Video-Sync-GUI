# vsg_qt/source_settings_dialog/__init__.py
# -*- coding: utf-8 -*-
"""Source settings dialog for per-source correlation configuration."""
from .dialog import SourceSettingsDialog

__all__ = ['SourceSettingsDialog']
