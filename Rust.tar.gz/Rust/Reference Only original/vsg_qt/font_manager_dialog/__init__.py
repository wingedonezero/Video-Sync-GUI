# vsg_qt/font_manager_dialog/__init__.py
from .ui import FontManagerDialog

__all__ = ['FontManagerDialog']
