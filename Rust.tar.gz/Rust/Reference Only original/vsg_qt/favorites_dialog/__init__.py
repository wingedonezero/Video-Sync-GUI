# vsg_qt/favorites_dialog/__init__.py
from .ui import FavoritesManagerDialog

__all__ = ['FavoritesManagerDialog']
