# -*- coding: utf-8 -*-
from .window import MainWindow
__all__ = ["MainWindow"]
