# vsg_qt/job_queue_dialog/__init__.py
from .ui import JobQueueDialog
__all__ = ["JobQueueDialog"]
