# vsg_qt/resample_dialog/__init__.py
from .ui import ResampleDialog
__all__ = ["ResampleDialog"]
