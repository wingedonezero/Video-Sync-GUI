# vsg_qt/style_editor_dialog/__init__.py
from .ui import StyleEditorDialog
__all__ = ["StyleEditorDialog"]
