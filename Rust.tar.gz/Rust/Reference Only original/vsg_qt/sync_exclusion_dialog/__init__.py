# vsg_qt/sync_exclusion_dialog/__init__.py
# -*- coding: utf-8 -*-
"""
Dialog for configuring frame sync style exclusions.
"""
from .ui import SyncExclusionDialog

__all__ = ['SyncExclusionDialog']
